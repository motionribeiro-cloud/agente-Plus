"""The Soma agent loop shared by Blender, Cinema 4D and the Figma bridge.

A host (the program) provides its tools; the agent exposes them through a local
MCP server and runs Claude Code or Codex headless for each turn, exactly like
the Adobe panel does. Tool calls arrive on the MCP server's threads and are
queued for the host's main thread: hosts call Agent.pump() from a timer.

Host interface (duck-typed):
    id, name, namespace         short id, display name, MCP server name
    instructions                system instructions (str)
    tools                       list of {"name", "description", "inputSchema"}
    call_tool(name, args)       runs on the main thread, returns
                                {"ok": bool, "data": ..., "error": str, "images": [png paths]}
"""
import base64
import json
import os
import platform
import queue
import re
import secrets
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import attachments, extensions, system, claude_health, knowledge
from .i18n import L

VERSION = "1.9.0-preview"
FEEDBACK_URL = "https://github.com/motionribeiro-cloud/agente-Plus/issues/new"
CLAUDE_EFFORTS = ["low", "medium", "high", "xhigh", "max"]
CLAUDE_MODELS = [
    {"id": "default", "model": None, "name": "Claude (default)", "efforts": [], "effort": None},
    {"id": "opus", "model": "opus", "name": "Claude Opus", "efforts": CLAUDE_EFFORTS, "effort": "high"},
    {"id": "sonnet", "model": "sonnet", "name": "Claude Sonnet", "efforts": CLAUDE_EFFORTS, "effort": "medium"},
    {"id": "haiku", "model": "haiku", "name": "Claude Haiku", "efforts": [], "effort": None},
]
PROVIDERS = {"claude": "Claude", "chatgpt": "ChatGPT", "antigravity": "Antigravity"}
AGY_DEFAULT = {"id": "default", "model": None, "name": "Antigravity (default)", "efforts": [], "effort": None}
HUB_URL = "http://127.0.0.1:47821"
IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}


def codex_home():
    return os.environ.get("CODEX_HOME") or os.path.join(system.HOME, ".codex")


def unavailable_file():
    return os.path.join(system.data_directory(), "codex-unavailable-models.json")


def unavailable_models():
    """Models the server refused for this ChatGPT account in the last week (shared with
    the Adobe panel): models_cache.json lists models whatever the plan."""
    try:
        with open(unavailable_file(), "r", encoding="utf-8") as handle:
            saved = json.load(handle)
    except (OSError, ValueError):
        return {}
    return {slug: when for slug, when in saved.items() if time.time() - when < 7 * 86400}


def remember_unavailable_model(slug):
    saved = unavailable_models()
    saved[slug] = time.time()
    try:
        with open(unavailable_file(), "w", encoding="utf-8") as handle:
            json.dump(saved, handle)
    except OSError:
        pass  # only costs one more refusal


def refused_codex_model(detail, selected):
    """The slug in a "model is not supported" failure, or None for any other failure."""
    if "model_not_found" not in detail and "model is not supported" not in detail.lower():
        return None
    found = re.search(r"The '([^']+)' model", detail)
    return found.group(1) if found else (selected.get("model") or "default")


def codex_models():
    models = [{"id": "default", "model": None, "name": "ChatGPT (default)", "efforts": [], "effort": None}]
    try:
        with open(os.path.join(codex_home(), "models_cache.json"), "r", encoding="utf-8") as handle:
            cache = json.load(handle)
        unavailable = unavailable_models()
        for m in cache.get("models", []):
            if m.get("slug") and m.get("visibility") != "hide" and m["slug"] not in unavailable:
                models.append({
                    "id": m["slug"], "model": m["slug"], "name": m.get("display_name") or m["slug"],
                    "efforts": [level.get("effort") for level in m.get("supported_reasoning_levels", []) if level.get("effort")],
                    "effort": m.get("default_reasoning_level"),
                })
    except (OSError, ValueError):
        pass
    return models



def feedback_url(program, ai=""):
    """New-issue link for suggestions and bug reports, with what the person is running."""
    body = L("**Version:** %s\n**Program:** %s\n**System:** %s\n**AI:** %s\n\n**What happened, or what do you suggest?**\n\n",
             "**Versão:** %s\n**Programa:** %s\n**Sistema:** %s\n**IA:** %s\n\n**O que aconteceu ou o que você sugere?**\n\n") % (
        VERSION, program, platform.platform(terse=True), ai or "-")
    return FEEDBACK_URL + "?" + urllib.parse.urlencode({"title": "[%s %s] " % (program, VERSION), "body": body})


class Settings:
    """Per-program preferences in the shared data folder."""

    def __init__(self, host_id):
        self.path = os.path.join(system.data_directory(), "soma-%s.json" % host_id)
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                self.values = json.load(handle)
        except (OSError, ValueError):
            self.values = {}

    def get(self, key, default=None):
        return self.values.get(key, default)

    def set(self, key, value):
        self.values[key] = value
        try:
            with open(self.path, "w", encoding="utf-8") as handle:
                json.dump(self.values, handle, indent=2)
        except OSError:
            pass


class _QuietServer(ThreadingHTTPServer):
    """Clients closing their connection early is normal; don't print tracebacks."""
    daemon_threads = True

    def handle_error(self, request, client_address):
        pass


class McpServer:
    """Streamable-HTTP MCP endpoint (JSON responses) on 127.0.0.1 with a bearer token."""

    def __init__(self, agent):
        self.agent = agent
        self.token = secrets.token_hex(24)
        self.httpd = None
        self.url = None

    def start(self):
        if self.httpd:
            return
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args):
                pass

            def _send(self, code, body=None):
                data = json.dumps(body).encode("utf-8") if body is not None else b""
                self.send_response(code)
                if body is not None:
                    self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                if data:
                    self.wfile.write(data)

            def do_DELETE(self):
                self._send(200 if self._authorized() else 401)

            def do_GET(self):
                self._send(405)

            def _authorized(self):
                return self.path.split("?")[0] == "/mcp" and self.headers.get("Authorization") == "Bearer " + server.token

            def do_POST(self):
                if not self._authorized():
                    self._send(401)
                    return
                length = int(self.headers.get("Content-Length") or 0)
                try:
                    body = json.loads(self.rfile.read(length).decode("utf-8"))
                except ValueError:
                    self._send(400, {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
                    return
                batch = isinstance(body, list)
                external = self.headers.get("X-Soma-Caller") == "hub"
                replies = [r for r in (server.handle(m, external) for m in (body if batch else [body])) if r is not None]
                if not replies:
                    self._send(202)
                    return
                self._send(200, replies if batch else replies[0])

        self.httpd = _QuietServer(("127.0.0.1", 0), Handler)
        self.url = "http://127.0.0.1:%d/mcp" % self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None

    def handle(self, message, external=False):
        if not isinstance(message, dict) or message.get("id") is None:
            return None
        params = message.get("params") or {}
        method = message.get("method")

        def reply(result):
            return {"jsonrpc": "2.0", "id": message["id"], "result": result}

        if method == "initialize":
            return reply({"protocolVersion": params.get("protocolVersion") or "2025-06-18",
                          "capabilities": {"tools": {"listChanged": False}},
                          "serverInfo": {"name": self.agent.host.namespace, "title": "Soma Agente", "version": VERSION}})
        if method == "ping":
            return reply({})
        if method == "tools/list":
            return reply({"tools": list(self.agent.host.tools) + extensions.TOOLS + knowledge.TOOLS})
        if method == "tools/call":
            if params.get("name") in {item["name"] for item in knowledge.TOOLS}:
                try:
                    data = knowledge.Library().tool(params["name"], params.get("arguments") or {})
                    return reply({"content": [{"type": "text", "text": json.dumps(data)}], "isError": False})
                except (ValueError, OSError, TypeError):
                    return reply({"content": [{"type": "text", "text": "Biblioteca indisponível; confira as pastas conectadas."}], "isError": True})
            name = params.get("name") or ""
            if name.startswith("soma_"):
                # Skills and connectors are files in the data folder: no main thread needed.
                result = extensions.call(name, params.get("arguments") or {})
                return reply({"content": [{"type": "text", "text": json.dumps(result, default=str)}], "isError": not result.get("ok")})
            result = self.agent.call_tool_from_mcp(name, params.get("arguments") or {}, external)
            return reply(result)
        return {"jsonrpc": "2.0", "id": message["id"], "error": {"code": -32601, "message": "Method not supported: %s" % method}}


class Agent:
    def __init__(self, host):
        self.host = host
        self.settings = Settings(host.id)
        self.provider = self.settings.get("provider", "claude")
        if self.provider not in PROVIDERS:
            self.provider = "claude"
        self.messages = []
        self.revision = 0
        self.busy = False
        self.status = L("Starting…", "Iniciando…")
        self.thread_id = None
        self.proc = None
        self.binary = None
        self.version = ""
        self.signed_in = None
        self.stop_requested = False
        self.lock = threading.RLock()
        self.tool_requests = queue.Queue()
        self.mcp = McpServer(self)
        self.turn_counter = 0
        self._temp_files = []

    # ------------------------------------------------------------------ state
    def _changed(self):
        self.revision += 1

    def add_message(self, role, text, key=None, **extra):
        with self.lock:
            if key is not None:
                for message in self.messages:
                    if message.get("key") == key:
                        message["text"] = text
                        message.update(extra)
                        self._changed()
                        return message
            message = {"role": role, "text": text, "key": key, "time": time.time()}
            message.update(extra)
            self.messages.append(message)
            self._changed()
            return message

    def set_status(self, text):
        self.status = text
        self._changed()

    @property
    def provider_name(self):
        return PROVIDERS[self.provider]

    def models(self):
        if self.provider == "antigravity":
            return [AGY_DEFAULT] + getattr(self, "_agy_models", [])
        return CLAUDE_MODELS if self.provider == "claude" else codex_models()

    def selected_model(self):
        models = self.models()
        wanted = self.settings.get("model." + self.provider)
        for model in models:
            if model["id"] == wanted:
                return model
        return models[0]

    def select_model(self, model_id):
        self.settings.set("model." + self.provider, model_id)
        self._changed()

    def selected_effort(self):
        model = self.selected_model()
        wanted = self.settings.get("effort." + self.provider)
        if wanted in model["efforts"]:
            return wanted
        return model["effort"] if model["effort"] in model["efforts"] else (model["efforts"][0] if model["efforts"] else None)

    def select_effort(self, effort):
        self.settings.set("effort." + self.provider, effort)
        self._changed()

    # ------------------------------------------------------------ lifecycle
    def start(self):
        self.mcp.start()
        self.refresh()
        if not getattr(self.host, "remote", False):
            threading.Thread(target=self._hub_heartbeat, daemon=True).start()
            threading.Thread(target=self._update_loop, daemon=True).start()

    # -------------------------------------------------------------- updates
    def _update_loop(self):
        """Asks the Soma Hub to check GitHub when the program opens, then every few hours."""
        time.sleep(5)
        while self.mcp.httpd:
            self.check_update()
            time.sleep(3 * 3600)

    def check_update(self, force=False):
        """Latest Release info from the Soma Hub ({} when the hub is off)."""
        try:
            self.update = extensions.hub_update("check", force)
        except RuntimeError as error:
            self.update = {}
            if force:
                self.add_message("error", str(error))
        if force and self.update:
            if self.update.get("status") == "error":
                self.add_message("error", L("Could not check for updates: ", "Não deu para verificar atualizações: ") + str(self.update.get("detail")))
            elif not self.update.get("available"):
                self.add_message("status", L("You have the latest version (%s).", "Você está na versão mais recente (%s).") % self.update.get("current", VERSION))
        self._changed()
        return self.update

    def install_update(self):
        """Installs the newer version as soon as no Adobe program is open."""
        try:
            self.update = extensions.hub_update("install")
        except RuntimeError as error:
            self.add_message("error", str(error))
        self._changed()

    def update_text(self):
        """One line for the panel when a newer version exists, else ""."""
        u = getattr(self, "update", None) or {}
        if not (u.get("available") and u.get("latest")):
            return ""
        if u.get("requested") and u.get("status") == "waiting":
            return u.get("detail") or L("Close the Adobe programs to install %s", "Feche os programas Adobe para instalar a %s") % u["latest"]
        if u.get("requested"):
            return L("Installing %s — reopen %s afterwards", "Instalando a %s — reabra o %s depois") % (u["latest"], self.host.name)
        return L("Soma Agente %s is available (you have %s)", "Soma Agente %s disponível (você tem a %s)") % (u["latest"], u.get("current", VERSION))

    def shutdown(self):
        self.stop()
        self._hub_post("/hub/unregister")
        self.mcp.stop()

    # ----------------------------------------------------------------- hub
    def _hub_post(self, path):
        """Tells the Soma Hub where this program's tools are; skipped when the hub is not running."""
        if not self.mcp.url:
            return
        body = json.dumps({"id": self.host.id, "name": self.host.name, "namespace": self.host.namespace,
                           "url": self.mcp.url, "token": self.mcp.token}).encode("utf-8")
        try:
            request = urllib.request.Request(HUB_URL + path, data=body, method="POST", headers={"Content-Type": "application/json"})
            urllib.request.urlopen(request, timeout=3).read()
        except OSError:
            pass

    def _hub_heartbeat(self):
        while self.mcp.httpd:
            self._hub_post("/hub/register")
            time.sleep(30)

    def refresh(self):
        """Finds the binary and checks the sign-in in the background."""
        def work():
            if self.provider == "antigravity":
                self._refresh_agy()
                return
            self.binary = system.find_claude() if self.provider == "claude" else system.find_codex()
            if not self.binary:
                self.signed_in = None
                if self.provider == "claude":
                    self.set_status((L("The Claude app does not include Claude Code — ", "O app do Claude não inclui o Claude Code — ") if system.has_claude_app()
                                     else L("Claude Code not found — ", "Claude Code não encontrado — ")) +
                                    L("click Connect to install it (needs a Pro or Max plan)", "clique em Conectar para instalar (precisa do plano Pro ou Max)"))
                else:
                    self.set_status(L("Codex not found — install the Codex app (chatgpt.com/codex)", "Codex não encontrado — instale o app Codex (chatgpt.com/codex)"))
                return
            env = system.environment(self.binary)
            try:
                out = subprocess.run([self.binary, "--version"], capture_output=True, text=True, timeout=30, env=env, creationflags=system.hidden_window_flags())
                self.version = (out.stdout or "").strip()
                if self.provider == "claude":
                    out = subprocess.run([self.binary, "auth", "status"], capture_output=True, text=True, timeout=30, env=env, creationflags=system.hidden_window_flags())
                    try:
                        self.signed_in = out.returncode == 0 and bool(json.loads(out.stdout or "{}").get("loggedIn")) and not getattr(self, "auth_failure", None)
                    except ValueError:
                        self.signed_in = False
                else:
                    out = subprocess.run([self.binary, "login", "status"], capture_output=True, text=True, timeout=30, env=env, creationflags=system.hidden_window_flags())
                    self.signed_in = out.returncode == 0 and "logged in" in ((out.stdout or "") + (out.stderr or "")).lower()
            except (OSError, subprocess.SubprocessError) as error:
                self.signed_in = None
                self.set_status(L("Could not start %s: %s", "Não deu para iniciar o %s: %s") % (self.provider_name, error))
                return
            if self.provider == "claude" and self.signed_in:
                self.set_status("Login Claude salvo; conexão será validada na próxima execução.")
                return
            if self.provider == "claude" and getattr(self, "auth_failure", None):
                self.set_status(self.auth_failure["message"])
                return
            self.set_status(L("%s ready", "%s pronto") % self.provider_name if self.signed_in else L("%s is not signed in — click Connect", "%s sem login — clique em Conectar") % self.provider_name)
        threading.Thread(target=work, daemon=True).start()

    def _refresh_agy(self):
        """Antigravity: find agy and list the account's models (agy models works
        only when signed in, so it doubles as the sign-in check)."""
        self.binary = system.find_agy()
        if not self.binary:
            self.signed_in = None
            self.set_status((L("The Antigravity app does not include its CLI (agy) — ", "O app do Antigravity não inclui a CLI (agy) — ") if system.has_antigravity_app()
                             else L("Antigravity CLI (agy) not found — ", "CLI do Antigravity (agy) não encontrada — ")) +
                            L("click Connect to install it", "clique em Conectar para instalar"))
            return
        try:
            out = subprocess.run([self.binary, "models"], capture_output=True, text=True, timeout=45,
                                 env=system.environment(self.binary), creationflags=system.hidden_window_flags(), stdin=subprocess.DEVNULL)
            models = []
            for line in (out.stdout or "").splitlines():
                parts = line.split("\t")
                if len(parts) == 2 and parts[0].strip() and " " not in parts[0].strip():
                    models.append({"id": parts[0].strip(), "model": parts[0].strip(), "name": parts[1].strip(), "efforts": [], "effort": None})
            self._agy_models = models
            self.signed_in = out.returncode == 0 and bool(models)
        except (OSError, subprocess.SubprocessError):
            self.signed_in = False
        if self.signed_in and not system.ensure_antigravity_config():
            self.set_status(L("Antigravity ready, but the Soma Hub is not running — reinstall Soma or start “Soma Hub”", "Antigravity pronto, mas o Soma Hub não está rodando — reinstale o Soma ou abra o “Soma Hub”"))
            return
        self.set_status(L("Antigravity ready", "Antigravity pronto") if self.signed_in else L("Antigravity is not signed in — click Connect", "Antigravity sem login — clique em Conectar"))

    def set_provider(self, provider):
        if provider not in PROVIDERS or provider == self.provider:
            return
        if self.busy:
            self.add_message("error", L("Wait for the current request to finish before switching the AI.", "Espere o pedido atual terminar antes de trocar a IA."))
            return
        self.provider = provider
        self.settings.set("provider", provider)
        # The conversation continues: the new AI starts its own session and gets
        # the chat so far with the next message (see _with_history).
        with self.lock:
            self.thread_id = None
        if any(m["role"] in ("user", "assistant") for m in self.messages):
            self.add_message("status", L("Switched to %s — the conversation continues.", "Trocado para o %s — a conversa continua.") % self.provider_name)
        self.set_status(L("Starting %s…", "Iniciando o %s…") % self.provider_name)
        self.refresh()

    def open_feedback(self):
        """A new GitHub issue prefilled with the version, program, system and AI."""
        system.open_url(feedback_url(self.host.name, self.provider_name))

    def login(self):
        self.auth_failure = None
        if not self.binary:
            # Claude Code and the agy CLI have official one-line installers; run them and check again after.
            if system.WINDOWS:
                done = L("Done. This window closes in a few seconds.", "Pronto. Esta janela fecha em alguns segundos.")
            else:
                done = L("Done. You can close this window; Soma checks again by itself.", "Pronto. Pode fechar esta janela; o Soma verifica de novo sozinho.")
            proc = system.install_cli(self.provider, done)
            if proc is None:
                system.open_url({"claude": "https://code.claude.com/docs/en/setup", "chatgpt": "https://chatgpt.com/codex", "antigravity": "https://antigravity.google/docs/getting-started"}[self.provider])
                return
            self.set_status(L("Installing %s in the window that opened…", "Instalando o %s na janela que abriu…") % ("Claude Code" if self.provider == "claude" else "Antigravity CLI"))
            threading.Thread(target=lambda: (proc.wait(), self.refresh()), daemon=True).start()
            return
        if self.provider == "antigravity":
            system.open_login_window(self.binary, [], "Antigravity login")
        elif self.provider == "claude":
            system.open_login_window(self.binary, ["auth", "login"], "Claude login")
        else:
            system.open_login_window(self.binary, ["login"], "ChatGPT login")
        self.set_status(L("Finish signing in in the browser, then click Check", "Termine o login no navegador e clique em Verificar"))

        def poll():
            deadline = time.time() + 300
            while time.time() < deadline and not self.signed_in:
                time.sleep(4)
                self.refresh()
        threading.Thread(target=poll, daemon=True).start()

    def new_chat(self):
        if self.busy:
            return
        with self.lock:
            self.thread_id = None
            self.messages = []
            self._changed()

    # ------------------------------------------------------------- tools
    def call_tool_from_mcp(self, name, args, external=False):
        """Runs on an MCP server thread: hands the call to the main thread and waits.
        External calls come from another agent (Antigravity) through the Soma Hub."""
        if external:
            self.add_message("tool", "MCP externo · " + self._tool_label(name, args), state="done", tool=name)
        elif self.busy and self.stop_requested:
            return {"content": [{"type": "text", "text": json.dumps({"ok": False, "error": "Request stopped; the tool was not run."})}], "isError": True}
        done = threading.Event()
        holder = {}
        self.tool_requests.put((name, args, holder, done))
        done.wait()
        result = holder.get("result") or {"ok": False, "error": "The tool did not return."}
        images = result.pop("images", None) or []
        content = [{"type": "text", "text": json.dumps(result, default=str)}]
        for path in images:
            try:
                with open(path, "rb") as handle:
                    data = base64.b64encode(handle.read()).decode("ascii")
                content.append({"type": "image", "mimeType": "image/png", "data": data})
            except OSError:
                pass
            finally:
                try:
                    os.remove(path)
                except OSError:
                    pass
        return {"content": content, "isError": result.get("ok") is not True}

    def pump(self, budget=0.05):
        """Main thread: runs queued tool calls. Returns True when something ran."""
        ran = False
        started = time.time()
        while time.time() - started < budget:
            try:
                name, args, holder, done = self.tool_requests.get_nowait()
            except queue.Empty:
                break
            ran = True
            try:
                holder["result"] = self.host.call_tool(name, args)
            except Exception as error:  # noqa: BLE001 - every failure goes back to the model
                holder["result"] = {"ok": False, "error": "%s: %s" % (type(error).__name__, error)}
            finally:
                done.set()
        return ran

    # -------------------------------------------------------------- turns
    def send(self, text, files=None):
        """files: images, videos, audio, PDFs or documents (see attachments.py)."""
        text = (text or "").strip()
        files = [p for p in (files or []) if p and os.path.isfile(p)]
        if self.busy or (not text and not files):
            return False
        if not self.binary or not self.signed_in:
            self.add_message("error", L("Connect your %s account first (Connect button).", "Conecte sua conta %s primeiro (botão Conectar).") % self.provider_name)
            return False
        names = ", ".join(os.path.basename(p) for p in files)
        label = text + ("" if not files else L("\n[Attached: %s]", "\n[Anexos: %s]") % names)
        prompt = self._with_history(text)
        self.add_message("user", label)
        self.busy = True
        self.stop_requested = False
        self.set_status(L("Working…", "Trabalhando…"))
        threading.Thread(target=self._run_turn, args=(prompt, files), daemon=True).start()
        return True

    def _with_history(self, text):
        """A new session (after switching the AI) gets the chat so far, so the
        conversation carries on where the previous AI left it."""
        if self.thread_id is not None:
            return text
        lines = []
        for m in self.messages:
            if m["role"] == "user":
                lines.append("User: " + m["text"])
            elif m["role"] == "assistant":
                lines.append("Assistant: " + m["text"])
        if not lines:
            return text
        history = "\n\n".join(lines)[-12000:]
        return ("<previous_conversation>\nThe conversation so far in this program (possibly with another AI). "
                "Continue from it; the work it describes is already in the document.\n\n%s\n</previous_conversation>\n\n%s" % (history, text))

    def stop(self):
        self.stop_requested = True
        proc = self.proc
        if proc:
            try:
                proc.kill()
            except OSError:
                pass

    def _instructions(self):
        extra = (self.settings.get("instructions") or "").strip()
        return self.host.instructions + " " + knowledge.INSTRUCTIONS + " " + extensions.instructions() + ((" Persistent user instructions for every request: " + extra) if extra else "")

    def _finish(self, error=None):
        self.proc = None
        self.busy = False
        if self.stop_requested:
            self.add_message("status", L("Stopped.", "Interrompido."))
        elif error:
            self.add_message("error", error)
        self.set_status(L("%s ready", "%s pronto") % self.provider_name)
        for path in self._temp_files:
            try:
                os.remove(path)
            except OSError:
                pass
        self._temp_files = []

    def _run_turn(self, text, files):
        self.turn_counter += 1
        key = "t%d:" % self.turn_counter
        parts = []
        try:
            context = knowledge.Library().context(text)
            if context["documents"]:
                text += "\n\n<soma_knowledge_reference>" + json.dumps(context, ensure_ascii=True) + "</soma_knowledge_reference>"
        except (ValueError, OSError, TypeError):
            self.add_message("status", "Biblioteca não consultada; confira as pastas de conhecimento.")
        try:
            if files:
                self.set_status(L("Reading the attachments…", "Lendo os anexos…"))
                parts = attachments.prepare(files, status=lambda step: self.set_status(
                    L("Downloading FFmpeg to read the video (only the first time)…", "Baixando o FFmpeg para ler o vídeo (só na primeira vez)…")))
                self.set_status(L("Working…", "Trabalhando…"))
            if self.provider == "claude":
                error = self._run_claude(text, parts, key)
            elif self.provider == "antigravity":
                error = self._run_agy(text, parts, key)
            else:
                error = self._run_codex(text, parts, key)
        except Exception as failure:  # noqa: BLE001
            error = "%s: %s" % (type(failure).__name__, failure)
        # Video frames and audio extracted for this message.
        work = os.path.join(system.data_directory(), "attachments")
        for folder in {os.path.dirname(p["path"]) for p in parts if p.get("path", "").startswith(work)}:
            shutil.rmtree(folder, ignore_errors=True)
        self._finish(error)

    @staticmethod
    def _plain_parts(parts, image_note):
        """Attachments as text lines plus image files, for agents that take no PDF or image blocks."""
        lines, images = [], []
        for part in parts:
            if part["type"] == "text":
                lines.append(part["text"])
            elif part["type"] == "image":
                images.append(part["path"])
                lines.append(image_note % ((len(images), part["path"]) if image_note.count("%") == 2 else len(images)))
            elif part["type"] == "pdf":
                lines.append("Text of the PDF:\n" + part["text"])
        return lines, images

    def _tool_label(self, name, args):
        summary = args.get("summary") if isinstance(args, dict) else None
        return summary or name.replace("_", " ")

    def _run_claude(self, text, parts, key):
        data_dir = system.data_directory()
        prompt_path = os.path.join(data_dir, "system-prompt-%s.txt" % self.host.id)
        with open(prompt_path, "w", encoding="utf-8") as handle:
            handle.write(self._instructions())
        config_path = os.path.join(data_dir, "mcp-config-%s.json" % self.host.id)
        servers = extensions.claude_servers()
        servers[self.host.namespace] = {"type": "http", "url": self.mcp.url, "headers": {"Authorization": "Bearer " + self.mcp.token}}
        with open(config_path, "w", encoding="utf-8") as handle:
            json.dump({"mcpServers": servers}, handle)
        allowed = ",".join("mcp__" + name + "__*" for name in servers)
        args = [self.binary, "-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose",
                "--system-prompt-file", prompt_path, "--mcp-config", config_path, "--strict-mcp-config",
                "--tools", "", "--allowedTools", allowed, "--permission-mode", "dontAsk"]
        if self.thread_id:
            args += ["--resume", self.thread_id]
        model = self.selected_model()
        if model["model"]:
            args += ["--model", model["model"]]
        effort = self.selected_effort()
        if effort and model["efforts"]:
            args += ["--effort", effort]
        content = []
        for part in parts:
            if part["type"] == "text":
                content.append({"type": "text", "text": part["text"]})
            elif part["type"] == "image":
                with open(part["path"], "rb") as handle:
                    data = base64.b64encode(handle.read()).decode("ascii")
                content.append({"type": "image", "source": {"type": "base64", "media_type": part["media_type"], "data": data}})
            elif part["type"] == "pdf" and part["size"] <= attachments.MAX_PDF_BYTES:
                # Claude reads the PDF itself: pages, layout and pictures.
                with open(part["path"], "rb") as handle:
                    data = base64.b64encode(handle.read()).decode("ascii")
                content.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": data}})
            elif part["type"] == "pdf":
                content.append({"type": "text", "text": "The PDF is too large to send whole; its text:\n" + part["text"]})
        content.append({"type": "text", "text": text or "Use the attached references."})
        prefix = "mcp__" + self.host.namespace + "__"

        self.proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=data_dir, env=system.environment(self.binary), creationflags=system.hidden_window_flags())
        stderr = []
        threading.Thread(target=lambda: stderr.append(self.proc.stderr.read().decode("utf-8", "replace")), daemon=True).start()
        self.proc.stdin.write((json.dumps({"type": "user", "message": {"role": "user", "content": content}, "parent_tool_use_id": None, "session_id": ""}) + "\n").encode("utf-8"))
        self.proc.stdin.close()
        tools = {}
        final = None
        auth_failed = False
        for raw_line in self.proc.stdout:
            try:
                message = json.loads(raw_line.decode("utf-8"))
            except ValueError:
                continue
            if message.get("session_id"):
                self.thread_id = message["session_id"]
            kind = message.get("type")
            if kind == "assistant" and message.get("message"):
                if message.get("error") == "authentication_failed":
                    auth_failed = True
                for index, block in enumerate(message["message"].get("content") or []):
                    if block.get("type") == "text" and block.get("text") and not message.get("error"):
                        self.add_message("assistant", block["text"], key=key + message["message"].get("id", "") + ":%d" % index)
                    elif block.get("type") == "tool_use":
                        name = str(block.get("name", "")).replace(prefix, "")
                        if name.startswith("mcp__"):
                            # A connector's tool: show it as "<connector>: <tool>".
                            parts = name.split("__", 2)
                            name = "%s: %s" % (parts[1], parts[2]) if len(parts) == 3 else name
                        tools[block.get("id")] = name
                        self.add_message("tool", self._tool_label(name, block.get("input") or {}), key=key + str(block.get("id")), state="running", tool=name)
            elif kind == "user" and isinstance((message.get("message") or {}).get("content"), list):
                for block in message["message"]["content"]:
                    if block.get("type") == "tool_result" and block.get("tool_use_id") in tools:
                        k = key + str(block["tool_use_id"])
                        for m in self.messages:
                            if m.get("key") == k:
                                m["state"] = "failed" if block.get("is_error") else "done"
                        self._changed()
            elif kind == "result":
                final = message
        self.proc.wait()
        if self.stop_requested:
            return None
        health = claude_health.classify(final, "".join(stderr), self.proc.returncode)
        self.auth_failure = health if health["auth"] else None
        if health["auth"]:
            self.signed_in = False
            return health["message"]
        if auth_failed:
            self.signed_in = False
            return L("Claude is not signed in. Click Connect and finish the login in your browser.", "O Claude está sem login. Clique em Conectar e termine o login no navegador.")
        if health["ok"]:
            self.auth_failure = None
            return None
        if not final:
            self.thread_id = None
        detail = (final and (final.get("result") or " ".join(final.get("errors") or []))) or "".join(stderr).strip()
        return detail or "Claude Code exited with code %s." % self.proc.returncode

    def _run_agy(self, text, parts, key):
        """Antigravity CLI. It has no per-run MCP option, so it reaches this program
        through the Soma Hub registered in Antigravity's MCP config (server "soma")."""
        extensions.sync_antigravity()
        if not system.ensure_antigravity_config():
            return "The Soma Hub is not running, so Antigravity cannot reach %s. Reinstall Soma Agente or start “Soma Hub” from the Start menu." % self.host.name
        workspace = os.path.join(system.data_directory(), "antigravity-workspace")
        os.makedirs(workspace, exist_ok=True)
        prompt = []
        if not self.thread_id:
            prompt.append("<soma_instructions>\n%s\nYou reach %s through the soma MCP server: call get_app_tools with app=\"%s\" once, then call_app_tool with app=\"%s\" for every action. "
                          "Skills and connectors are managed with the soma_* tools of the same soma server (soma_create_skill, soma_read_skill, soma_add_connector...). "
                          "Other open programs are listed by list_apps if the user asks to combine programs. Do not use the terminal, browser or file-editing tools for work in %s.\n</soma_instructions>"
                          % (self._instructions(), self.host.name, self.host.id, self.host.id, self.host.name))
        prompt += self._plain_parts(parts, "[Attached image #%d, file path: %s]")[0]
        prompt.append(text or "Use the attached references.")
        # Headless agy only runs tools allowed in its settings: the three Soma Hub
        # tools (see system.ensure_antigravity_config); everything else is denied.
        args = [self.binary, "-p", "\n\n".join(prompt), "--output-format", "stream-json"]
        model = self.selected_model()
        if model["model"]:
            args += ["--model", model["model"]]
        if self.thread_id:
            args += ["--conversation", self.thread_id]
        self.proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=workspace, env=system.environment(self.binary), creationflags=system.hidden_window_flags())
        stderr = []
        threading.Thread(target=lambda: stderr.append(self.proc.stderr.read().decode("utf-8", "replace")), daemon=True).start()
        texts = {}
        result = None
        for raw_line in self.proc.stdout:
            try:
                event = json.loads(raw_line.decode("utf-8"))
            except ValueError:
                continue
            kind = event.get("event")
            if event.get("conversation_id"):
                self.thread_id = event["conversation_id"]
            if kind == "step_update":
                step = event.get("step_update") or {}
                index = step.get("step_index")
                step_type = step.get("step_type") or ""
                if step.get("conversation_id"):
                    self.thread_id = step["conversation_id"]
                if step_type == "agent_response":
                    texts[index] = texts.get(index, "") + (step.get("text_delta") or "")
                    if texts[index].strip():
                        self.add_message("assistant", texts[index].strip(), key="%sstep%s" % (key, index))
                elif step_type and step_type != "user_input":
                    params = (step.get("tool_info") or {}).get("parameters") or {}
                    inner = params.get("Arguments") if isinstance(params.get("Arguments"), dict) else {}
                    label = inner.get("tool") or params.get("ToolName") or step.get("tool_name") or step_type
                    label = str(label).replace("_", " ")
                    state = {"DONE": "done", "ERROR": "failed", "FAILED": "failed"}.get(step.get("state"), "running")
                    self.add_message("tool", str(label), key="%sstep%s" % (key, index), state=state, tool=step_type)
            elif kind == "result":
                result = event.get("result") or {}
                if result.get("conversation_id"):
                    self.thread_id = result["conversation_id"]
        self.proc.wait()
        if self.stop_requested:
            return None
        if result and result.get("status") == "SUCCESS":
            if not texts and result.get("response"):
                self.add_message("assistant", result["response"].strip(), key=key + "final")
            return None
        detail = (result and (result.get("error") or result.get("status"))) or "".join(stderr).strip()[-1500:]
        if "auth" in detail.lower() or "login" in detail.lower():
            self.signed_in = False
            return L("Antigravity is not signed in. Click Connect and finish the login.", "O Antigravity está sem login. Clique em Conectar e termine o login.")
        return detail or "Antigravity exited with code %s." % self.proc.returncode

    def _run_codex(self, text, parts, key, retries=0, default_refused=False):
        thread_before = self.thread_id
        data_dir = system.data_directory()
        ns = self.host.namespace
        args = [self.binary, "exec", "--json", "--skip-git-repo-check", "--ignore-user-config", "-s", "read-only", "-C", data_dir,
                "-c", "mcp_servers.%s.url=%s" % (ns, json.dumps(self.mcp.url)),
                "-c", "mcp_servers.%s.bearer_token_env_var=\"SOMA_MCP_TOKEN\"" % ns,
                "-c", "mcp_servers.%s.default_tools_approval_mode=\"approve\"" % ns,
                "-c", "mcp_servers.%s.tool_timeout_sec=3600" % ns,
                "-c", "approval_policy=\"never\"",
                "-c", "developer_instructions=" + json.dumps(self._instructions())] + extensions.codex_overrides()
        model = self.selected_model()
        if model["model"]:
            args += ["-m", model["model"]]
        effort = self.selected_effort()
        if effort and model["efforts"]:
            args += ["-c", "model_reasoning_effort=" + json.dumps(effort)]
        if self.thread_id:
            args.append("resume")
        prompt, images = self._plain_parts(parts, "[Attached image #%d]")
        args += ["--image=" + path for path in images]
        if self.thread_id:
            args.append(self.thread_id)
        args.append("-")
        prompt.append(text or "Use the attached references.")
        env = system.environment(self.binary)
        env["SOMA_MCP_TOKEN"] = self.mcp.token
        self.proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=data_dir, env=env, creationflags=system.hidden_window_flags())
        stderr = []
        threading.Thread(target=lambda: stderr.append(self.proc.stderr.read().decode("utf-8", "replace")), daemon=True).start()
        self.proc.stdin.write("\n\n".join(prompt).encode("utf-8"))
        self.proc.stdin.close()
        completed = False
        failure = None
        worked = False
        for raw_line in self.proc.stdout:
            try:
                event = json.loads(raw_line.decode("utf-8"))
            except ValueError:
                continue
            kind = event.get("type")
            item = event.get("item") or {}
            if kind == "thread.started" and event.get("thread_id"):
                self.thread_id = event["thread_id"]
            elif kind in ("item.started", "item.completed") and item:
                if item.get("type") == "agent_message" and kind == "item.completed" and item.get("text"):
                    worked = True
                    self.add_message("assistant", item["text"], key=key + item.get("id", ""))
                elif item.get("type") == "mcp_tool_call":
                    worked = True
                    state = "running" if kind == "item.started" else ("done" if item.get("status") == "completed" and not item.get("error") else "failed")
                    self.add_message("tool", self._tool_label(item.get("tool", ""), item.get("arguments") or {}), key=key + item.get("id", ""), state=state, tool=item.get("tool"))
            elif kind == "turn.completed":
                completed = True
            elif kind == "turn.failed":
                failure = (event.get("error") or {}).get("message") or "ChatGPT could not finish the request."
            elif kind == "error" and event.get("message"):
                failure = event["message"]
        self.proc.wait()
        if self.stop_requested:
            return None
        if completed and not failure:
            return None
        detail = failure or "".join(stderr).strip() or "Codex exited with code %s." % self.proc.returncode
        # The server refused the model before any work: try another one with the same request.
        refused = None if worked else refused_codex_model(detail, model)
        if refused:
            name = model["name"] if model["model"] else refused
            default_refused = default_refused or not model["model"]
            remember_unavailable_model(refused)
            self.thread_id = thread_before
            nxt = next((m for m in codex_models() if bool(m["model"]) == default_refused), None)
            if nxt and retries < 4:
                self.select_model(nxt["id"])
                self.add_message("status", L("%s is not available on your ChatGPT account. Switched to %s.", "O %s não está disponível na sua conta do ChatGPT. Troquei para %s.") % (name, nxt["name"]))
                return self._run_codex(text, parts, key, retries + 1, default_refused)
            return L("Your ChatGPT account did not accept any of the models Codex lists. Update Codex and check your plan, then try again.",
                     "Sua conta do ChatGPT não aceitou nenhum dos modelos que o Codex lista. Atualize o Codex, confira seu plano e tente de novo.")
        lowered = detail.lower()
        if "not logged in" in lowered or "unauthorized" in lowered or "401" in lowered:
            self.signed_in = False
            return L("ChatGPT is not signed in. Click Connect and finish the login in your browser.", "O ChatGPT está sem login. Clique em Conectar e termine o login no navegador.")
        return detail
